/*
 * oscillators.h
 *
 *  Created on: Sep 13, 2023
 *      Author: ishaburange
 */

#ifndef SRC_OSCILLATORS_H_
#define SRC_OSCILLATORS_H_

#include<stdio.h>
#include "em_cmu.h"
#include "app.h"

void initOscillators();


#endif /* SRC_OSCILLATORS_H_ */
